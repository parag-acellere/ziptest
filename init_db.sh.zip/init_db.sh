#!/bin/bash

#[[ ":$PATH:" != *":/usr/bin:"* ]] && PATH="/usr/bin:${PATH}"

#  Change the database name
export GAMMA_DATABASE="${GAMMA_DATABASE:-gamma}" 
export ANALYTICS_DATABASE="${ANALYTICS_DATABASE:-corona}" 
export PGUSER="${PGUSER:-postgres}" 
export PGPASSWORD="${PGPASSWORD:-postgres}" 
export PGHOST="${PGHOST:-localhost}" 
export PGPORT="${PGPORT:-5432}" 

read_v=0
#create_v=0
#patch_v=0
drop_v=0
windows_v=0
migrate_corona_v=0
migrate_all_corona_v=0

# Fix for relative paths
DIR="`dirname \"$0\"`"

# Fix for cloud path issue
#PSQL_BIN = 'psql'

read_input(){
	read -e -p "Enter GAMMA_DATABASE:" -i $GAMMA_DATABASE GAMMA_DATABASE
	read -e -p "Enter ANALYTICS_DATABASE:" -i $ANALYTICS_DATABASE ANALYTICS_DATABASE
	read -e -p "Enter PGPORT:" -i $PGPORT PGPORT
}

echo_input(){
	echo Using below database configuration
	echo -------------------------------------
	echo Connection:  	$PGUSER $PGPASSWORD $PGHOST $PGPORT
	echo Database: 		$GAMMA_DATABASE $ANALYTICS_DATABASE
	echo -------------------------------------
}

open_connections(){
	psql -t -c "
		SELECT client_addr 
			|| ' is running ' 
			|| String_agg(
			CASE 
			WHEN application_name = '' THEN 'Unknown' || '(' || pid || ')' 
			ELSE application_name || '(' || pid || ')' END
			, ',') AS open_connections 
		FROM   pg_stat_activity 
		WHERE  datname = '$GAMMA_DATABASE'  or datname = '$ANALYTICS_DATABASE'
		GROUP  BY client_addr; 
	"
}

# For reconciling previous versions to flyway DB migration approach, check if their table schema_version exists
# Decision to baseline/migrate is based on presence of this table
schema_version_exists(){
	psql -t -d $1 -c "select count(*) from pg_tables where tablename='schema_version'"
}

drop_db(){
	OPEN_CONNECTIONS="$(open_connections)"
	if [[ -z "${OPEN_CONNECTIONS// }" ]] 
	then
	    echo "Dropping DB" $GAMMA_DATABASE
		dropdb --if-exists $GAMMA_DATABASE
		echo "Dropping DB" $ANALYTICS_DATABASE
		dropdb --if-exists $ANALYTICS_DATABASE
	else
		echo "$OPEN_CONNECTIONS" 1>&2
		exit 64
	fi
}

# TODO: Check and delete
#create_baseline() {
	# $1 = database name
	# $2 = baseline version number to be assigned
	# $3 = directory which has the migration scripts, relative to $DIR
#	echo "Creating recon baseline" $2 "for" $1
#	$DIR/flyway-4.2.0/flyway -locations=filesystem:$DIR/$3/migrate -baselineVersion=$2 \
#		-baselineDescription="Gamma Baseline" -user=$PGUSER -password=$PGPASSWORD \
#		-url=jdbc:postgresql://$PGHOST:$PGPORT/$1 baseline
#	if [ $? -eq 0 ]; then
#		echo "Initialized" $1 "recon baseline to" $2
#	else
#		echo "Could not initialize" $1 "recon baseline to" $2
#		exit $?
#	fi
#}

run_migration() {
	# $1 = database name
	# $2 = directory which has the migration scripts, relative to $DIR
	# $3 = baseline on migrate?
	$DIR/flyway-5.2.4/flyway -baselineOnMigrate=$3 \
	-locations=filesystem:$DIR/$2/migrate \
	-user=$PGUSER \
	-password=$PGPASSWORD  \
	-schemas=$ANALYTICS_SCHEMA \
	-url=jdbc:postgresql://$PGHOST:$PGPORT/$1 migrate
	if [ $? -eq 0 ]; then
		echo "Migrated" $1
	else
		echo "Could not migrate" $1
		exit $?
	fi
}

patch_db(){
	# $1 = database name
	# $2 = directory which has the migration scripts, relative to $DIR
	echo "Migrating" $1 "DB on schema :" $ANALYTICS_SCHEMA
	SCHEMA_EXISTS="$(schema_version_exists $1)"
	if [ $SCHEMA_EXISTS -eq 0 ]; then
		baselineOnMigrate="true"
	else
		baselineOnMigrate="false"
 	fi	
	
 	run_migration $1 $2 $baselineOnMigrate
}

# Check if data got populated correctly in the 'tenant_schema','db_host','db_info_id' etc column in tenant_db_info, db_info, subsystems tables
# Decision to drop columns based on presence of this data
data_migrated_successfully(){
	psql -t -d $1 -c "	SELECT 0 FROM tenant_db_info WHERE tenant_schema is NULL
						UNION
						SELECT 0 FROM db_info WHERE db_host is NULL or db_port is NULL or db_name is NULL or db_user is NULL or db_password is NULL 
						UNION
						SELECT 0 FROM subsystems WHERE db_info_id is NULL"
}


# Check if 'db_host' column exists in table db_info
# Decision to migrate is based on presence of this column
column_exists(){
	psql -t -d $1 -c "SELECT count(*) as value FROM information_schema.columns WHERE table_name='db_info' and column_name='db_host'"
}


# Check if any 'has_snapshot' column is already set to true
# Decision to migrate is based on if the value is already set for this column
flag_already_set(){
	psql -t -d $1 -c "SELECT count(*) as value FROM subsystems WHERE has_snapshot = true"
}


db_info_migration(){
 	psql -t -d $GAMMA_DATABASE -c "ALTER TABLE db_info ADD COLUMN IF NOT EXISTS db_host CHARACTER VARYING;
 	ALTER TABLE db_info ADD COLUMN IF NOT EXISTS db_port INTEGER;
	ALTER TABLE db_info ADD COLUMN IF NOT EXISTS db_name CHARACTER VARYING;
	ALTER TABLE db_info ADD COLUMN IF NOT EXISTS db_user CHARACTER VARYING;
	ALTER TABLE db_info ADD COLUMN IF NOT EXISTS db_password CHARACTER VARYING;
	ALTER TABLE db_info ALTER COLUMN info DROP NOT NULL;
	ALTER TABLE tenant_db_info ADD COLUMN IF NOT EXISTS tenant_schema CHARACTER VARYING;
	ALTER TABLE tenant_db_info ALTER COLUMN tenant_db_info DROP NOT NULL;
	ALTER TABLE subsystems ADD COLUMN IF NOT EXISTS db_info_id INTEGER REFERENCES db_info (id);"

	for tenant_db_info in `psql -t -d $GAMMA_DATABASE -c "select tenant_db_info from tenant_db_info;"`; 
			do
				export tenant_db_info_json=$(java -jar $DIR/CryptoUtils.jar "$tenant_db_info" 0)
				export tenant_schema=$(java -jar $DIR/JSONParser.jar "$tenant_db_info_json" "ANALYTICS_SCHEMA")
				export tenant_uid=$(java -jar $DIR/JSONParser.jar "$tenant_db_info_json" "TENANT_UID")
				#echo $tenant_db_info_json
				#echo $tenant_schema $tenant_uid
				psql -t -d $GAMMA_DATABASE -c "UPDATE tenant_db_info SET tenant_schema = '$tenant_schema' WHERE tenant_uid = '$tenant_uid';"
			done

	for db_info_data in `psql -t -d $GAMMA_DATABASE -c "select id||'_'||info from db_info;"`; 
		    do
		    	
		    	export db_info_id="$(cut -d'_' -f1 <<<$db_info_data)"
				export db_info="$(cut -d'_' -f2 <<<$db_info_data)"
				echo "-----> " $db_info_data 
				echo "-----> " $db_info
				echo "-----> " $db_info_id
				export db_info_json=$(java -jar $DIR/CryptoUtils.jar "$db_info" 0)
				export db_host=$(java -jar $DIR/JSONParser.jar "$db_info_json" "PGHOST")
				export db_port=$(java -jar $DIR/JSONParser.jar "$db_info_json" "PGPORT")
				export db_name=$(java -jar $DIR/JSONParser.jar "$db_info_json" "ANALYTICS_DATABASE")
				export db_user=$(java -jar $DIR/JSONParser.jar "$db_info_json" "PGUSER")
				export db_password=$(java -jar $DIR/JSONParser.jar "$db_info_json" "PGPASSWORD")

				export db_user_encry=$(java -jar $DIR/CryptoUtils.jar "$db_user" 1)
				export db_password_encry=$(java -jar $DIR/CryptoUtils.jar "$db_password" 1)
				
				psql -t -d $GAMMA_DATABASE -c "UPDATE db_info SET db_host = '$db_host', db_port = '$db_port', db_name = '$db_name', db_user = '$db_user_encry', db_password = '$db_password_encry' 
												WHERE id = '$db_info_id';"
				psql -t -d $GAMMA_DATABASE -c "UPDATE subsystems SET db_info_id = $db_info_id 
												WHERE subsystem_database_host = '$db_host' 
												AND subsystem_database_port = '$db_port' 
												AND subsystem_database_name = '$db_name'
												AND subsystem_database_user_name = '$db_user_encry'
												AND subsystem_database_password = '$db_password_encry';"
			done

}

#update_db_details(){
#subsystem and tenant_db_info changes/add db_info id
 #echo 'temp2'
#}

apply_patch(){
	# patch_db $ANALYTICS_DATABASE "analytics"
	export ANALYTICS_SCHEMA=public
	patch_db $GAMMA_DATABASE "gamma"
	#db_info update - migration
	COLUMN_EXISTS="$(column_exists $GAMMA_DATABASE)"
	if [ $COLUMN_EXISTS -ne 1 ]; then
		db_info_migration
 	fi
	
	#has_snapshot flag update 
	HAS_SNAPSHOT_FLAG_POPULATED="$(flag_already_set $GAMMA_DATABASE)"
	if [ $HAS_SNAPSHOT_FLAG_POPULATED -eq 0 ]; then
		update_has_snapshot_flag
 	fi
	DB_INFO_DATA_MIGRATED="$(data_migrated_successfully $GAMMA_DATABASE)"
	if [ -z $DB_INFO_DATA_MIGRATED ]; then
		psql -t -d $GAMMA_DATABASE -c "ALTER TABLE db_info DROP COLUMN IF EXISTS info;
									   ALTER TABLE tenant_db_info DROP COLUMN IF EXISTS tenant_db_info;"
	elif [ $DB_INFO_DATA_MIGRATED -eq 0 ]; then
		echo "WARN : Problem in db_info data migration, DB_INFO_DATA_MIGRATED : $DB_INFO_DATA_MIGRATED"
 	fi
	
	#Generating cumulative .sql for all functions
	generate_cumulative_functions
	import_gamma_functions
	#Setting corona_migration_status to 0 (Corona migration not done) and invalidating all logged-in users
	psql -t -d $GAMMA_DATABASE -c "UPDATE tenant set corona_migration_status = 0, corona_migration_additional_details = jsonb_build_object('info', 'Corona schema migration not done', 'updated_on', now());
								   DELETE FROM token WHERE token_type = 'user';"
	
	#The following code would not execute if -m option is not provided while running init_db.sh
	if [ $migrate_corona_v = '1' ]
	then
		apply_analytics_patch_for_all_schemas
	fi
	
	echo ""
	echo "-------------------------------------"
	echo "Patch application process completed."
	echo "-------------------------------------"
}

apply_analytics_patch_for_all_schemas(){
	export ANALYTICS_SCHEMA="public"
	export PGOPTIONS="-c client_min_messages=error --search_path=$ANALYTICS_SCHEMA"
if [ "$( psql -d $GAMMA_DATABASE -tAc "SELECT 1 FROM pg_database WHERE datname='$ANALYTICS_DATABASE'" )" = '1' ]
	then
			schemaCounter=1
		    for schemaName in `psql -t -d $ANALYTICS_DATABASE -c "select schema_name from information_schema.schemata where schema_name like 'schema_%' or schema_name = 'public';"`; 
		    do
		    	psql -t -d $GAMMA_DATABASE -c "UPDATE tenant set corona_migration_status = 1, corona_migration_additional_details = jsonb_build_object('info', 'Corona schema migration inprogress', 'updated_on', now()) FROM tenant_db_info WHERE tenant_db_info.tenant_schema = '$schemaName' AND tenant_db_info.tenant_uid = tenant.tenant_uid;"
				echo ""
		    	echo "***********************************************"
		    	echo "Runnning migration on schema # " $schemaCounter
		    	echo "***********************************************"
		    	echo ""
		    	export ANALYTICS_SCHEMA="$schemaName"
		    	export PGOPTIONS="-c client_min_messages=error --search_path=$ANALYTICS_SCHEMA"
			    patch_db $ANALYTICS_DATABASE "analytics"
			    import_corona_functions
				#Setting corona_migration_status to 2 (Corona migration done)
				export ANALYTICS_SCHEMA="public"
				export PGOPTIONS="-c client_min_messages=error --search_path=$ANALYTICS_SCHEMA"
				psql -t -d $GAMMA_DATABASE -c "UPDATE tenant set corona_migration_status = 2, corona_migration_additional_details = jsonb_build_object('info', 'Corona schema migrated successfully', 'updated_on', now()) FROM tenant_db_info WHERE tenant_db_info.tenant_schema = '$schemaName' AND tenant_db_info.tenant_uid = tenant.tenant_uid;"
			    schemaCounter=$(( $schemaCounter+1 ))
			done
	fi
	echo ""
	echo "-------------------------------------"
	echo "$ANALYTICS_DATABASE patch application process completed."
	echo "-------------------------------------"
}

apply_analytics_patch(){

	echo "Creating $ANALYTICS_DATABASE DB"
	

	if [ "$( psql -d $GAMMA_DATABASE -tAc "SELECT 1 FROM pg_database WHERE datname='$ANALYTICS_DATABASE'" )" = '1' ]
	then
	    echo "Database already exists"
	else
	    echo "Database does not exist"
	    createdb --encoding UTF8 -O $PGUSER $ANALYTICS_DATABASE 
	fi


	export PGOPTIONS="-c client_min_messages=error --search_path=$ANALYTICS_SCHEMA"
	# dropdb --if-exists $ANALYTICS_DATABASE
	# echo "Creating $ANALYTICS_DATABASE DB"
	# createdb -O $PGUSER $ANALYTICS_DATABASE 

	patch_db $ANALYTICS_DATABASE "analytics"
	#psql -t -d $ANALYTICS_DATABASE -c
	# "create user $CURRENT_USER;
	# GRANT USAGE ON SCHEMA $ANALYTICS_SCHEMA TO $CURRENT_USER;
	# GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA $ANALYTICS_SCHEMA TO $CURRENT_USER;
	# GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA $ANALYTICS_SCHEMA TO $CURRENT_USER;
	# "
	
	generate_cumulative_functions
	import_corona_functions
}

update_has_snapshot_flag(){
	echo ""
	if [ "$( psql -d $GAMMA_DATABASE -tAc "SELECT 1 FROM pg_database WHERE datname='$ANALYTICS_DATABASE'" )" = '1' ]
	then
			schemaCounter=1
		    for schemaName in `psql -t -d $ANALYTICS_DATABASE -c "select schema_name from information_schema.schemata where schema_name like 'schema_%' or schema_name = 'public';"`; 
		    do
		    	export ANALYTICS_SCHEMA="$schemaName"
		    	export PGOPTIONS="-c client_min_messages=error --search_path=$ANALYTICS_SCHEMA"
			    for repoUID in `psql -t -d $ANALYTICS_DATABASE -c "SELECT ss.subsystem_uid 
														FROM snapshots sn 
														INNER JOIN subsystems ss ON ss.id=sn.subsystem_id AND (sn.status = 'P' OR sn.status = 'K') AND sn.analysis_mode <> 'R' 
														GROUP BY ss.subsystem_uid 
														HAVING COUNT(sn.id) > 0;"`; 
				do
					repoUID=$(echo $repoUID | sed -e 's/\r//g')
					export ANALYTICS_SCHEMA="public"
					export PGOPTIONS="-c client_min_messages=error --search_path=$ANALYTICS_SCHEMA"
					psql -d $GAMMA_DATABASE -tAc "UPDATE subsystems SET has_snapshot = true where subsystem_uid = '$repoUID' ; " 
				done
			done
			psql -d $GAMMA_DATABASE -tAc "UPDATE subsystems SET last_poll = NULL where has_snapshot = FALSE ; "
	#else
	    #echo "$ANALYTICS_DATABASE : Skipping patch application as database does not exist" 
	fi
	echo ""
}


create_db(){
	if [ "$( psql -d postgres -tAc "SELECT 1 FROM pg_database WHERE datname='$GAMMA_DATABASE'" )" = '1' ]
	then
		echo "Database already exists"
	else
		echo "Database does not exist, Creating $GAMMA_DATABASE DB"
		createdb --encoding UTF8 -O $PGUSER $GAMMA_DATABASE 
	fi
	echo "Creating analytics and gamma baseline and running migration"
	apply_patch
}

import_gamma_functions(){
	echo "Importing gamma functions"
	psql -d $GAMMA_DATABASE -f $DIR/gamma/gamma_func.sql
}

import_corona_functions(){
	echo "Importing analytics functions"
	psql -d $ANALYTICS_DATABASE -f $DIR/analytics/analytics_func.sql 
}

generate_cumulative_functions(){
	rm -rf $DIR/gamma/gamma_func.sql
	for file in `ls $DIR/gamma/functions/**/*.sql` 
	do 
		printf "\n" >> $DIR/gamma/gamma_func.sql
		echo "--" $file >> $DIR/gamma/gamma_func.sql
		cat $file >> $DIR/gamma/gamma_func.sql
		echo ";" >> $DIR/gamma/gamma_func.sql
	done 
	
	rm -rf $DIR/analytics/analytics_func.sql
	for file in `ls $DIR/analytics/functions/**/*.sql`
	do 
		printf "\n" >> $DIR/analytics/analytics_func.sql 
		echo "--" $file >> $DIR/analytics/analytics_func.sql 
		cat $file >> $DIR/analytics/analytics_func.sql 
		echo ";" >> $DIR/analytics/analytics_func.sql 
	done
}



# if [[ ! $@ =~ ^\-.+ ]]
# then
#   echo Usage
#   echo "$0 -r to specify database details GAMMA_DATABASE($GAMMA_DATABASE),ANALYTICS_DATABASE($ANALYTICS_DATABASE) and database port($PGPORT) else default database are used details "
#   echo "$0 -c to create database and apply functions to the newly created database"
#   echo "$0 -p to patch/only import functions to the existing database"
#   echo "$0 -d to drop existing database"
#   exit
# fi



if [ -z "$NO_OPT" ] 
then

	while getopts rdwma option; 
	do
	case "${option}" in
	r) read_v=1 ;;
	#c) create_v=1 ;;
	#p) patch_v=1 ;;
	d) drop_v=1 ;;
	w) windows_v=1 ;;
	m) migrate_corona_v=1 ;;
	a) migrate_all_corona_v=1 ;;
	esac
	done

	if [ $windows_v -eq 1 ]; then
		DIR=$GAMMA_ROOT/gamma_ui/dbscripts
		echo "Current script directory path : " $DIR
	fi
	
	if [ $read_v -eq 1 ]; then
		read_input
	fi
	echo_input
	
	if [ $drop_v -eq 1 ]; then
		drop_db
		exit 0
	fi

	if [ $migrate_all_corona_v -eq 1 ]; then
		apply_analytics_patch_for_all_schemas
		exit 0
	fi 
	

	#if [ $create_v -eq 1 ]; then
	if [ ! -f config/gamma-config.json ]; then
		cp config/gamma-config.json.template config/gamma-config.json 2>/dev/null || :
		if [ $read_v -eq 1 ]; then
			echo -------------------------------------
			echo -e "\e[5m Please update config/gamma-config.json with below settings. \e[25m"
			echo '"dbName"           : "$GAMMA_DATABASE",'
			echo -e "\e[5m And in analysisDBDetails sections \e[25m"
			echo '"dbName"           : "$ANALYTICS_DATABASE",'
			echo -------------------------------------
		fi
	fi	
	#if [ ! -f config/analysis-config.json ]; then
	#	echo -e "\e[5m Please update the paths in config/analysis-config.json \e[25m"
	#	cp config/analysis-config.json.template config/analysis-config.json 2>/dev/null || :
	#fi
	create_db
	#fi 

	#if [ $patch_v -eq 1 ]; then
	#	apply_patch
	#fi 


	
fi
